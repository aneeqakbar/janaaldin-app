from django.shortcuts import redirect, render
from django.views.generic import View
from django.contrib import messages

# Create your views here.

class ClassBookView(View):
    def get(self, request):
        return render(request, "classes/book.html")

    def post(self, request):
        return redirect("classes:ClassBookConfirmView")

class ClassBookConfirmView(View):
    def get(self, request):
        return render(request, "classes/book-confirm.html")

    def post(self, request):
        messages.success(request, "Class has been booked successfully, you will receive confirmination email shortly")
        return redirect("users:HomeView")
