from django.urls import path
from . import views


app_name = "classes"

urlpatterns = [
    path('book/', views.ClassBookView.as_view(), name='ClassBookView'),
    path('book-confirm/', views.ClassBookConfirmView.as_view(), name='ClassBookConfirmView'),
]
