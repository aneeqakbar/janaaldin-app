from django.contrib import admin
from .models import Class, ClassDateTime

# Register your models here.

admin.site.register(Class)
admin.site.register(ClassDateTime)
